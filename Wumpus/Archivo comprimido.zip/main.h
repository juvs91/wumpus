//
//  main.h
//  Wumpus
//
//  Created by juvs on 3/30/13.
//  Copyright (c) 2013 juvs. All rights reserved.
//

#ifndef main_h
#define main_h

#include "GlutHeader.h"

public:
    static void display(void);


#endif
