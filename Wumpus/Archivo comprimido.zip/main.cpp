//
//  main.cpp
//  Wumpus
//
//  Created by juvs on 3/27/13.
//  Copyright (c) 2013 juvs. All rights reserved.
//


#include "GlutHeader.h"

#include "World.h"


#include <stdlib.h>
#include <stdio.h>
#include <iostream>



World world;

    void display(void){
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
        glPushMatrix();
        world.draw();
        glPopMatrix();
        glutSwapBuffers();
    }



void init(int gridSize){
    glLoadIdentity();
    gluOrtho2D(0, gridSize,0, gridSize);
    glClearColor(1.0,0.20,0.20,1);//DEFINE EL COLOR DEL FONDO DE TU PANTALLA
    world.init(gridSize);
    glutPostRedisplay();
}


void keyboard(int key, int x, int y){
    switch (key) {
        case GLUT_KEY_DOWN:
            world.move(270);
            break;
        case GLUT_KEY_UP:
            world.move(90);
            break;
        case GLUT_KEY_RIGHT:
            world.move(0);
            break;
        case GLUT_KEY_LEFT:
            world.move(180);
            break;
    }
    glutPostRedisplay();
}

void onMenu(int opcion){
    //switch para seleccionar la opcion del menu 0 para salir , 1 para reiniciar y 2 para lanzar la flecha
    switch (opcion) {
        //Reiniciar el juego en facil
        case 0:
            init(world.SMALL);
            break;
            
        case 1:
            init(world.MEDIUM);
            break;
            
        case 2:
            init(world.LARGE);
            break;
            
        case 3:
            //lanza la flecha
            world.throwArrow();
            break;
            
        case 4:
            exit(0);//sale de la aplicacion
            break;
    }
    glutPostRedisplay();
    
}





void menu(){
    int menuOpciones, menuDificultad;
    
    menuDificultad= glutCreateMenu(onMenu);
     glutAddMenuEntry("Fácil", 0);
     glutAddMenuEntry("Medio", 1);
     glutAddMenuEntry("Difícil", 2);
    
    
	menuOpciones = glutCreateMenu(onMenu);
     glutAddSubMenu("Reinicializar",menuDificultad);
     glutAddMenuEntry("Lanzar flecha", 3);
     glutAddMenuEntry("EXIT", 4);
    
     glutAttachMenu(GLUT_RIGHT_BUTTON);
}


int main(int argc,char * argv[])
{
    // insert code here...
    glutInit(&argc, argv);
    glutInitWindowSize(960,720);
    glutInitWindowPosition(10,10);
    glutCreateWindow("Wumpus");
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE |GLUT_DEPTH);
    glutDisplayFunc(display);
    glutSpecialFunc(keyboard);
    init(world.LARGE);//hay que checar el gride size , para escojer el tamaño del grid
    menu();
    glutMainLoop();



    return 0;
}

