//
//  Explorer.cpp
//  Wumpus
//
//  Created by juvs on 3/27/13.
//  Copyright (c) 2013 juvs. All rights reserved.
//

#include "Explorer.h"




void Explorer::draw(){
    if (isVisible) {
        glPushMatrix();
            glTranslated(x+.5,y+.5,0);
            glRotated(directionAngle,0,1,0);
            //dibujar el muñeco
            glColor4f(0, 0, 1, 1);
            glutWireTeapot(.4);

        glPopMatrix();
    }
    
    
}
void Explorer::setDirectionAngle(int directionAngleIn){
    directionAngle=directionAngleIn;
}
int Explorer::getX(){
    return x;
}
int Explorer::getY(){
    return y;
}
int Explorer::getDirectionAngle(){
    return directionAngle;
}
void Explorer::setMoveAngles(std::vector<int> moveAnglesIn){
    moveAngles=moveAnglesIn;
}
std::vector<int> Explorer::getMoveAngles(){
    std::vector<int> lista;
    return lista;
}
void Explorer::throwArrow(){
    hasArrow=false;
}
void Explorer::setVisible(bool valIn){
    isVisible=valIn;
}
bool Explorer::getArrow(){
    
    return hasArrow;
    
}
void Explorer::init(){
    std::vector<int> initialMoveAngles={0,0,0,0};
    setPosition(0, 0);
    setDirectionAngle(0);
    setArrow();
    setMoveAngles(initialMoveAngles);
    setVisible(true);
}
void Explorer::setArrow(){
    hasArrow=true;
}
void Explorer::setPosition(float xIn,float yIn){
    x=xIn;
    y=yIn;
}
