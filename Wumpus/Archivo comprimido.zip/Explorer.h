//
//  Explorer.h
//  Wumpus
//
//  Created by juvs on 3/27/13.
//  Copyright (c) 2013 juvs. All rights reserved.
//

#ifndef Explorer_H
#define Explorer_H

#include "GlutHeader.h"


#include <vector>

class Explorer{
public:
    void setPosition(float xIn,float yIn);
    void draw();
    void setDirectionAngle(int directionAngle);
    int getX();
    int getY();
    int getDirectionAngle();
    void setMoveAngles(std::vector<int> moveAngleIn);
    std::vector<int> getMoveAngles();
    void throwArrow();
    void setVisible(bool val);
    bool getArrow();
    void init();
    
private:
    float x;
    float y;
    int directionAngle;
    std::vector<int> moveAngles;
    bool hasArrow;
    bool isVisible;
    void setArrow();

    
};

#endif /* defined(__Wumpus__Explorer__) */
