//
//  GlutHeader.h
//  Wumpus
//
//  Created by juvs on 3/29/13.
//  Copyright (c) 2013 juvs. All rights reserved.
//

#ifndef GlutHeader_h
#define GlutHeader_h

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


#endif
