//
//  Wumpus.cpp
//  Wumpus
//
//  Created by juvs on 3/27/13.
//  Copyright (c) 2013 juvs. All rights reserved.
//
#include <iostream>
#include "Wumpus.h"
void Wumpus::draw(){
    if (isAlive) {
        glPushMatrix();
            glTranslated(x+.5,y+.5,0);
            //dibujar el wumpus
            glColor4f(0, 1, 0, 1);
            glutWireTeapot(.4);
        glPopMatrix();
    }
    else{
        glPushMatrix();
        glTranslated(x+.5,y+.5,0);
        //dibujar el wumpus
        glColor4f(0, 0, 0, 1);
        glutWireTeapot(.4);
        glPopMatrix();
    }
}
void Wumpus::init(int gridSize){
    generateNewRandomPosition(gridSize);
    setAlive();
    
}
bool Wumpus::getAlive(){
    return isAlive;
}
int Wumpus::getX(){
    return x;
}
int Wumpus::getY(){
    return y;
}
void Wumpus::yell(){
    std::cout<<"grita";
    
}
void Wumpus::generateNewRandomPosition(int gridSize){
    x=rand()%gridSize;
    y=rand()%gridSize;
    if (x==0 && y==0) {
        generateNewRandomPosition(gridSize);
    }
}
void Wumpus::setAlive(){
    isAlive=true;
}
void Wumpus::killWumpus(){
    isAlive=false;
    yell();
}
